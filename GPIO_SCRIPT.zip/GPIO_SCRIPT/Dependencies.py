# Intel Corporation
# Townsend, Todd
# ww32

# This Script Installs all dependencies needed for KMB_GPIO_SCRIPT

# Dependencies for Serial Software - Linux - 

# Imports
import os.path, subprocess

# Install Dependencies Python3
subprocess.call(["sudo", "apt", "install", "python3-pip"])
subprocess.call(["sudo", "apt", "install", "python3-serial"])
subprocess.call(["sudo", "pip", "install", "pyserial"])
subprocess.call(["sudo", "pip", "install", "pyusb"])
subprocess.call(["sudo", "pip", "install", "ioctl-opt"])

# Install Dependencies Python2
subprocess.call(["sudo", "apt", "install", "python-pip"])
subprocess.call(["sudo", "apt", "install", "python-serial"])
subprocess.call(["sudo", "pip", "install", "pyserial"])
subprocess.call(["sudo", "pip", "install", "pyusb"])
subprocess.call(["sudo", "pip", "install", "ioctl-opt"])